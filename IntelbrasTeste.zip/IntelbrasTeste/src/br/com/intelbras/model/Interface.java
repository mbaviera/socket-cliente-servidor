/*
 * Nome             Interface.java
 * Date             18/03/2017
 * Autor            Mateus Rocha Baviera
 * Contato			mateusmtu@gmail.com
 * 
 */

package br.com.intelbras.model;

import br.com.intelbras.controller.SocketConnection;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class Interface extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField fieldIP;
	private JTextField fieldPorta;
	private JTextField fieldNome;
	private JLabel textIP;
	private JLabel textPorta;
	private JLabel textNome;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interface frame = new Interface();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Interface() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Teste T�cnico Intelbras");
		setResizable(false);
		setBounds(100, 100, 323, 260);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		fieldIP = new JTextField();
		fieldIP.setColumns(10);
		fieldPorta = new JTextField();
		fieldPorta.setColumns(10);
		fieldNome = new JTextField();
		fieldNome.setColumns(10);

		textIP = new JLabel("IP:");
		textPorta = new JLabel("Porta:");
		textNome = new JLabel("Nome:");

		JButton btnConectar = new JButton("Conectar");
		btnConectar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// armazena os valores informados pelo usuario
				String ip = fieldIP.getText();
				String porta = fieldPorta.getText();
				String nome = fieldNome.getText();

				SocketConnection socketClass = new SocketConnection();

				socketClass.setIpConexao(ip);
				socketClass.setPortaConexao(porta);
				socketClass.setNomeConexao(nome);

				// chamando a classe de SocketConnection
				try {
					socketClass.main(null);
				} catch (Exception e1) {
					e1.printStackTrace();
				}

				fieldIP.setText("");
				fieldPorta.setText("");
				fieldNome.setText("");

			}
		});

		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane
				.setHorizontalGroup(gl_contentPane
						.createParallelGroup(Alignment.LEADING)
						.addGroup(
								gl_contentPane
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.LEADING)
														.addGroup(
																gl_contentPane
																		.createSequentialGroup()
																		.addGroup(
																				gl_contentPane
																						.createParallelGroup(
																								Alignment.TRAILING)
																						.addComponent(
																								textIP)
																						.addComponent(
																								textPorta)
																						.addComponent(
																								textNome))
																		.addGap(18)
																		.addGroup(
																				gl_contentPane
																						.createParallelGroup(
																								Alignment.LEADING)
																						.addComponent(
																								fieldIP,
																								209,
																								238,
																								Short.MAX_VALUE)
																						.addComponent(
																								fieldNome,
																								GroupLayout.DEFAULT_SIZE,
																								238,
																								Short.MAX_VALUE)
																						.addComponent(
																								fieldPorta,
																								GroupLayout.DEFAULT_SIZE,
																								238,
																								Short.MAX_VALUE))
																		.addContainerGap())
														.addGroup(
																Alignment.TRAILING,
																gl_contentPane
																		.createSequentialGroup()
																		.addComponent(
																				btnConectar,
																				GroupLayout.PREFERRED_SIZE,
																				155,
																				GroupLayout.PREFERRED_SIZE)
																		.addGap(54)))));
		gl_contentPane
				.setVerticalGroup(gl_contentPane
						.createParallelGroup(Alignment.LEADING)
						.addGroup(
								gl_contentPane
										.createSequentialGroup()
										.addGap(44)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																fieldIP,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(textIP))
										.addGap(18)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																fieldPorta,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(textPorta))
										.addGap(18)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																fieldNome,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(textNome))
										.addGap(18).addComponent(btnConectar)
										.addContainerGap(40, Short.MAX_VALUE)));
		contentPane.setLayout(gl_contentPane);

	}

}
