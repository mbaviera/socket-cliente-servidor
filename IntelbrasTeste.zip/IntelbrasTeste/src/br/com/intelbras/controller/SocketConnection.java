/*
 * Nome            	SocketConnection.java
 * Date             18/03/2017
 * Autor            Mateus Rocha Baviera
 * Contato			mateusmtu@gmail.com
 * 
 */

package br.com.intelbras.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.Socket;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class SocketConnection {

	static String ipConexao;
	static String portaConexao;
	String nomeConexao;

	public void main(String[] args) throws Exception {

		Socket socket = null;
		File arquivo = new File("Arquivo de Logs.txt");
		// escrita no arquivo de log
		FileWriter fileWriter = new FileWriter(arquivo, true);
		BufferedWriter escrever = new BufferedWriter(fileWriter);

		if (arquivo.exists() == false) {
			try {
				// cria o arquivo para escrever a mensagem
				arquivo.createNewFile();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		try {
			// inicia a conexao com o servidor
			System.out.println("Iniciando conexao com o servidor");
			socket = new Socket(ipConexao, Integer.parseInt(portaConexao));
			System.out.println("Conexao estabelecida");
			JOptionPane.showMessageDialog(null, "Conexao Estabelecida!");
		} catch (Exception e) {
			System.err.println("Erro de conexao com o servidor.");
			JOptionPane
					.showMessageDialog(null,
							"Erro de Conexao com o servidor! Verifique o IP e a Porta!");
		}

		try {
			// recebe a mensagem do servidor
			@SuppressWarnings("resource")
			Scanner s = new Scanner(socket.getInputStream());
			String msg = s.nextLine();

			// escrevendo a mensagem no arquivo
			escrever.write("\r\n" + msg + " -" + nomeConexao
					+ " - Conexao Realizada com Sucesso!");
			escrever.close();
			fileWriter.close();
		} catch (Exception e) {
		}
	}

	public String getIpConexao() {
		return ipConexao;
	}

	public void setIpConexao(String ipConexao) {
		SocketConnection.ipConexao = ipConexao;
	}

	public String getPortaConexao() {
		return portaConexao;
	}

	public void setPortaConexao(String portaConexao) {
		SocketConnection.portaConexao = portaConexao;
	}

	public String getNomeConexao() {
		return nomeConexao;
	}

	public void setNomeConexao(String nomeConexao) {
		this.nomeConexao = nomeConexao;
	}

}
