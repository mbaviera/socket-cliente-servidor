/*
 * Nome             Gerenciador.java
 * Date             18/03/2017
 * Autor            Mateus Rocha Baviera
 * Contato			mateusmtu@gmail.com
 * 
 */

package be.com.intelbras.servidor;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Gerenciador extends Thread {

	private Socket cliente;

	public Gerenciador(Socket cliente) {
		this.cliente = cliente;
		start();
	}

	@Override
	public void run() {

		// armazena a data e hora da conexao
		Date data = new Date();
		SimpleDateFormat formatar = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		String dataFormatada = formatar.format(data);

		try {
			// envia para a aplica��o a mensagem
			while (true) {// mandar diversas mensagens

				PrintWriter escritor = new PrintWriter(
						cliente.getOutputStream(), true);
				escritor.println(dataFormatada);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
