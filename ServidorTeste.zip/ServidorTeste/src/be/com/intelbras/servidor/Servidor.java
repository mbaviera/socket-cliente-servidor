/*
 * Nome             Servidor.java
 * Date             18/03/2017
 * Autor            Mateus Rocha Baviera
 * Contato			mateusmtu@gmail.com
 * 
 */

package be.com.intelbras.servidor;

import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
	public static void main(String[] args) throws Exception {
		ServerSocket server = null;

		try {
			// iniciando o servidor na porta 2525
			System.out.println("Iniciando servidor");
			server = new ServerSocket(2525);
			System.out.println("Aguardando conexao");

			while (true) {
				// aguarda novas conexoes
				Socket cliente = server.accept();

				// inicia um novo gerenciar de clientes quando chega uma nova
				// conexao
				new Gerenciador(cliente);
			}
		} catch (Exception e) {
			System.err.println("Porta n�o dispon�vel ou ocupada.");

			try {
				if (server != null)
					server.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}
}
